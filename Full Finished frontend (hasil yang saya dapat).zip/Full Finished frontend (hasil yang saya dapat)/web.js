function replace(){
    document.getElementById("detail1").style.display="none";
    document.getElementById("detail2").style.display="block";
    document.getElementById("button1").style.display="none";
    document.getElementById("button2").style.display="block";
}

function replaceBack(){
    document.getElementById("detail2").style.display="none";
    document.getElementById("detail1").style.display="block";
    document.getElementById("button2").style.display="none";
    document.getElementById("button1").style.display="block";
}



